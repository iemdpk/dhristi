<?php
require('con.php');
$name = $_POST['name'];
$email = $_POST['email'];
$number = $_POST['number'];
$college = $_POST['college'];
$pwd = $_POST['password'];

$sql = "INSERT INTO `joining`(`name`, `email`, `number`, `college`, `password`) VALUES('$name','$email','$number','$college','$pwd')";

$query = mysqli_query($db,$sql);
?>

<!DOCTYPE html>
<html lang="en">
    <head>
  <title>Dhristi</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="js/parallax.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/regiphp.css"/>
    <link href="https://fonts.googleapis.com/css?family=Acme|Chilanka|Luckiest+Guy|Maven+Pro&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css"/>
</head>

<body>
<nav  class="navbar navbar-expand-lg fixed-top navbar-light bg-info">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
    <a class="navbar-brand" href="#">Dhristi</a>
    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <a class="nav-link" href="index.html">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="donation.html">Donation</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active" href="#">JoinUs</a>
      </li>
      <li class="nav-item">
          <a class="nav-link" href="#">whoweare</a>
      </li>
    </ul>
    
  </div>
</nav>


        <div class="deepka jumbotron jumbotron-fluid bg-info">
            <h1 style="Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif; text-align: center;">SignUp Forum</h1>
            <p style="text-align: center;">Now You Are in the Family</p>
        </div>
         <div class="padu display-1"><h1>Thank You So Much You got a Mail After Some Time</h1></div>
         <hr class="w-75" >
         <?php
         echo '<div class="padu display-1"><h1>'. $name .'</h1></div>';
         ?>
         <hr class="w-75">

<div class="footer">
    <p>Made By heart</p>
</div>
    
    </body>
</html>