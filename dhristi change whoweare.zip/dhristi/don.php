<?php
	require('con.php');
	$name = $_POST['name'];
	$email = $_POST['email'];
	$addr = $_POST['addr'];
	$num = $_POST['number'];
	$college = $_POST['college'];
	$kapda = $_POST['clothes'];

	$sql23  = "INSERT INTO `donation`(`name`, `email`, `address`, `number`, `college`, `clothes`) VALUES ('$name','$email','$addr','$num','$college','$kapda')";
	$mysql = mysqli_query($db,$sql23);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Dhristi</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="js/parallax.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/doncss.css"/>
    <link href="https://fonts.googleapis.com/css?family=Acme|Chilanka|Luckiest+Guy|Maven+Pro&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css"/>
</head>

<body>

<nav class="navbar navbar-expand-lg fixed-top navbar-light bg-info">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01">
    <span class="navbar-toggler-icon"></span>
  </button>
  <a  class="info navbar-brand text-danger">Dhristi</a>
  <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a  class="ranger nav-link active text-dark" href="index.html">Home</a>
      </li>
      <li class="nav-item">
        <a  class="ranger nav-link text-dark" href="donation.html">Donation</a>
      </li>
      <li class="nav-item">
        <a  class="ranger nav-link text-dark" href="joinus.html">JoinUs</a>
      </li>
	<li class="nav-item">
        <a class="ranger nav-link text-dark" href="log.html">Login</a>
      </li>

      <li class="nav-item">
          <a  class="ranger nav-link text-dark" href="who.html">Whoweare</a>
      </li>
    </ul>
    
  </div>
</nav>


        <div class=" deepak412 jumbotron jumbotron-fluid bg-info">
            <h1 style="Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif; text-align: center;">Donation Forum</h1>
            <p style="text-align: center;">Currently We Are taking Only Clothes</p>
        </div>

        <div class="kadu display-1"><h1>Thankew So Much Your One Step Can make Happy Many Minds</h1></div>
        <div class="kadu display1"><h1>Our Team Will Call You</h1></div>
        <hr class="w-75">
        <?php
        echo '<div class="kadu display-1"><h1>'.$name.'</h1></div>'
        ?>
        <hr class="w-75">
<div class="footer">
    <p>Made By heart</p>
</div>
    
    </body>
</html>
