<?php
require('con.php');
$name = $_POST['name'];
$email = $_POST['email'];
$number = $_POST['number'];
$college = $_POST['college'];
$pwd = $_POST['password'];

$sql = "INSERT INTO `joining`(`name`, `email`, `number`, `college`, `password`) VALUES('$name','$email','$number','$college','$pwd')";
$query = mysqli_query($db,$sql);

$sended=mail($email,"Invitation to a Charity Program","Dear Sir,
Congratulation,greetings from the management team of the Dhristi .
It is hereby informed you that on the upcoming dated we are starting
a noble act. We will collect all the old and useless clothes,books 
and many other things etc. which are useless for us . And we will 
donate these to the people who are needed on the slum and construction 
area .

This camp will work under the warm guidance of some special and 
educated persons on our society who have the extraordinary ability 
and experiences to handle this.

Please join the camp and make this initiative act on the succesful direction.\n
Our aims:

1. collect the old books, clothes and many more
2. clean these properly
3. keep it safe in proper manner
4. distribute these on the requirement area 
5. And many more

You can visit our website for updates and we will provide a 
whatsapp app group after sometime.
For any further query you can contact our responsible member:
Mohit: 7903007558
");
?>

<!DOCTYPE html>
<html lang="en">
    <head>
  <title>Dhristi</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="js/parallax.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/regiphp.css"/>
    <link href="https://fonts.googleapis.com/css?family=Acme|Chilanka|Luckiest+Guy|Maven+Pro&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css"/>
</head>

<body>
<nav class="navbar navbar-expand-lg fixed-top navbar-light bg-info">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01">
    <span class="navbar-toggler-icon"></span>
  </button>
  <a class="info navbar-brand text-danger">Dhristi</a>
  <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a  class="ranger nav-link active text-dark" href="index.html">Home</a>
      </li>
      <li class="nav-item">
        <a  class="ranger nav-link text-dark" href="gallery.html">Gallery</a>
      </li>
      <li class="nav-item">
        <a  class="ranger nav-link text-dark" href="donation.html">Donation</a>
      </li>
      <li class="nav-item">
        <a  class="ranger nav-link text-dark" href="joinus.html">JoinUs</a>
      </li>
	<li class="nav-item">
        <a class="ranger nav-link text-dark" href="log.html">Login</a>
      </li>

      <li class="nav-item">
          <a  class="ranger nav-link text-dark" href="who.html">Whoweare</a>
      </li>
    </ul>
    
  </div>
</nav>


        <div class="deepka jumbotron jumbotron-fluid bg-info">
            <h1 style="Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif; text-align: center;">SignUp Forum</h1>
            <p style="text-align: center;">Now You Are in the Family</p>
        </div>
         <div class="padu display-1"><h1>Thank You So Much You got a Mail After Some Time</h1></div>
         <hr class="w-75" >
         <?php
         echo '<div class="padu display-1"><h1>'. $name .'</h1></div>';
         ?>
         <hr class="w-75">

<div class="footer">
    <p>Made By heart</p>
</div>
    
    </body>
</html>
