<?php 
	require('con.php');
	session_start();
	$email = $_POST['t1'];
	$pass = $_POST['pass'];
	$daa = date("Y-m-d");
	echo $email . "  ". $daa . $pass;
	$sql = "SELECT * FROM `joining` WHERE `email` = '$email' AND `password` = '$pass'";
	$query = mysqli_query($db,$sql);
	$rows = mysqli_num_rows($query);
	if(!$query){
		echo "Sorry Retry Again";
	}
	else
	{
		printf("%d",$rows);
		if($rows == 1){
			$_SESSION['noker'] = $email;
		 	header("Location:report.php");
		}
		else
		{	
			echo '<script>'.'alert("You enter An incorrect Password");'.'</script>';
		}
	}


?>


