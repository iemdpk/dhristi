<?php   
	require('con.php');
	$sql = "select * from `report`";
	$query = mysqli_query($db,$sql);
	?>
<html>
<head>
	<title>mehboob Data</title>
</head>
<body style="background-color:cyan; text-align:center">
	<hr />
	<marquee style="color:red;font-size:38px;">
		Mehboob Darling Bhai You Are Awsome Banda Ke Liye Sorry Yr
	</marquee>
	<hr />
	<table style="font-size:30px; text-align:center; margin-left:30%;"  border=1>
	<tr  >
	<td>Date</td>
	<td>Name</td>
	<td>Report</td>
	<tr>
	<?php
	while($run = mysqli_fetch_assoc($query))
	{
		echo '<tr>'.
			'<td>'.$run['date'].'</td>'.
			'<td>'.$run['name'].'</td>'.
			'<td>'.$run['report'].'</td>'.
			'</tr>';
	}
	?>
	</table>
	
</body>
</html>
