<?php
	require('con.php');
	session_start();
	$name_1 = $_SESSION['noker'];
	$sql = "SELECT * FROM `joining` WHERE `email` = '$name_1'";
	$query = mysqli_query($db,$sql);
	$array = mysqli_fetch_array($query);
?>


<!DOCTYPE html>
<html lang="en">
    <head>
  <title>Dhristi</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="js/parallax.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/report.css"/>
    <link href="https://fonts.googleapis.com/css?family=Acme|Chilanka|Luckiest+Guy|Maven+Pro&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css"/>
</head>

<body>
<nav class="navbar navbar-expand-lg fixed-top navbar-light bg-info">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01">
    <span class="navbar-toggler-icon"></span>
  </button>
  <a  class="info navbar-brand text-danger">Dhristi</a>
  <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a  class="ranger nav-link active text-dark" href="index.html">Home</a>
      </li>
      <li class="nav-item">
        <a  class="ranger nav-link text-dark" href="gallery.html">Gallery</a>
      </li>
      <li class="nav-item">
        <a  class="ranger nav-link text-dark" href="donation.html">Donation</a>
      </li>
      <li class="nav-item">
        <a  class="ranger nav-link text-dark" href="joinus.html">JoinUs</a>
      </li>
      <li class="nav-item">
        <a class="ranger nav-link text-dark" href="log.html">Login</a>
      </li>

      <li class="nav-item">
          <a  class="ranger nav-link text-dark" href="who.html">Whoweare</a>
      </li>
    </ul>
    
  </div>
</nav>
	<div class="deepka jumbotron jumbotron-fluid bg-info">
	<h1 style="Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif; text-align: center;"><?php echo"Hy ".$array['name']; ?></h1>
            <p style="text-align: center;">Enter Your Report Daily It Helps Us A lot</p>
	</div>
	<hr class="w-75" />
	<marquee class="mar">Please Update Daily It Help Us A lot for me and those People</marquee>
	<hr class="w-75"/>
	<!-----Main table---->
	<div class="row">
	<div class="col-sm-12 text-center">
	<form action="mainre.php" method="post">
	<div class="form-group">
	<label style="font-size:15px;" for="report">Report</label>
	<textarea class="champion form-control" name="report" id="exampleFormControlTextarea2" rows="20" placeholder="I have Done Champaning,Dilvery Two Clothes, Donating Some Clothes"></textarea>
	</div>
	<div class="form-control">
	<input type="Submit" value="Thats All" class="btn btn-lg btn-primary center-block">
	</div>
	
</form>
</div>
</div>

<div class="footer">
    <p>Made By heart</p>
</div>

</body>
</html>
